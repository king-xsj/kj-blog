package com.kim;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import pojo.Stu;

@Configuration
public class SpringBootConfig {

    @Bean
    public Stu stu() {
        return new Stu("kim", 18);
    }
}
