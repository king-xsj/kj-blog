package com.kim.controller;

import com.kim.utils.JSONResult;
import com.kim.utils.MyAsyncTask;
import com.sun.org.apache.bcel.internal.generic.ARETURN;
import com.sun.org.apache.xerces.internal.impl.xpath.XPath;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import pojo.Stu;
import pojo.Student;

import java.io.File;
import java.util.Arrays;
import java.util.Map;

//@Controller
@RestController
//@RequestMapping("stu")
@Slf4j
public class HelloController {
    //@RequestMapping("hello")
    //@ResponseBody
    @Autowired
    private MyAsyncTask myAsyncTask;

    @GetMapping("hello")
    public String Hello() {
        myAsyncTask.publicMsg();
        log.info("开始先执行");
        return "hello world, My frie12!!!";
    }

    @GetMapping("{stuId}/get")
    public String get(@PathVariable("stuId") String stuId,
                      @RequestParam("name") String name,
                      @RequestParam("age") Integer age) {
        log.info(stuId + name + age);
        return "这是获取参数" + stuId + name + age;
    }
    @PostMapping("/submit")
    public String submitData(@RequestParam("name") String name, @RequestParam("age") int age) {
        // 处理请求
        System.out.println(name + ":" + age);
        return "Hello r, " + name + "!" + "My age is" + age;
    }

    @Autowired
    private Stu stu;

    @GetMapping("getStu")
    public Object getStu(){
        return stu;
    }

    @GetMapping("getStudent")
    public JSONResult getStudent(){
        Student stu = new Student();
        stu.setName("kimmm");
        stu.setAge(188);
        log.info(stu.name + "zhesihnnnnnnnn");
        return JSONResult.ok(stu);
    }

    @Value("${app.name.xxx.yyy.zzz}")
    private String xyz;

    @GetMapping("getXyz")
    public Object getXyz() {
        return xyz;
    }

    @PostMapping("create")
    public String create(@RequestBody Map<String, Object> stuMap,
                         @RequestHeader("token") String token) {
        log.info("stuMap:" + stuMap.toString());
        log.info("token:" + token);
        //log.info("clientId:", clientId);
        return "新增数据";
    }
    @PostMapping("uploadFile")
    public JSONResult uploadFile(MultipartFile file) throws Exception{
        file.transferTo(new File("D:/code/test/temp", file.getOriginalFilename()));
        return JSONResult.ok("上传成功");
    }
}
