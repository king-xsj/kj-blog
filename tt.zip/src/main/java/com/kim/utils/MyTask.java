package com.kim.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.LocalDateTime;
import java.util.Locale;

//@Configuration
//@EnableScheduling
@Slf4j
public class MyTask {
    @Scheduled(cron = "*/5 * * * * ?")
    public void publicMsg(){
        log.warn("开始====》" + LocalDateTime.now());
    }
    //常用的定时任务表达式:
    //‌每隔5秒执行一次‌：*/5 * * * * ?
    //‌每隔1分钟执行一次‌：0 */1 * * * ?
    //‌每天23点执行一次‌：0 0 23 * * ?
    //‌每天凌晨1点执行一次‌：0 0 1 * * ?
    //‌每月1号凌晨1点执行一次‌：0 0 1 1 * ?
    //‌每月最后一天23点执行一次‌：0 0 23 L * ?
    //‌每周星期天凌晨1点执行一次‌：0 0 1 ? * L
    //‌每天上午10点、下午2点和4点触发‌：0 0 10,14,16 * * ?
    //‌朝九晚五工作时间内每半小时触发‌：0 0/30 9-17 * * ?
    //‌每个星期三中午12点触发‌：0 0 12 ? * WED
    //‌每周二、四、六下午5点触发‌：0 0 17 ? * TUES,THUR,SAT
}

