package pojo;

import lombok.Data;

@Data
public class Student {
    public String name;
    public Integer age;
}
